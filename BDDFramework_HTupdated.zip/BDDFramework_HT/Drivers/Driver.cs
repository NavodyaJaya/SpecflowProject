﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BDDFramework_HT.Drivers
{
    public class Driver
    {
        public static IWebDriver driver;

        public void BrowserSetUp()
        {

            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
            driver.Url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            

        }

        public void CloseBrowser() { 
            driver.Quit();
        }
    }
}
