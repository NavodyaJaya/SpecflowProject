﻿using BDDFramework_HT.Drivers;
using SeleniumExtras.PageObjects;
using Dynamitey.DynamicObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace BDDFramework_HT.PageObjects
{
    public class LoginPage
    {
        public LoginPage()
        {

            PageFactory.InitElements(Driver.driver, this);
        }

        [FindsBy(How = How.Name, Using = "username")]
        public IWebElement Username { get; set; }

        [FindsBy(How = How.Name, Using = "password")]
        public IWebElement Password { get; set; }

        [FindsBy(How = How.XPath, Using = "//button[@type='submit']")]
        public IWebElement LoginButton { get; set; }


        public void AddLoginCredentials(string username, string password)
        {
            Username.SendKeys(username);
            Password.SendKeys(password);
        }

        public void ClickLogin()
        {
            LoginButton.Click();
        }

        public string NavigatedToHomePage() {

            return (Driver.driver.Url.ToString());
        }
    }
}
