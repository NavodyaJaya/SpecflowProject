using BDDFramework_HT.Drivers;
using BDDFramework_HT.PageObjects;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace BDDFramework_HT.StepDefinitions
{
    [Binding]
    public class LoginStepDefinitions
    {
        LoginPage loginPageObject;
        Driver driverPageObject = new Driver();

        [BeforeScenario]
        public static void SetUpUserForScenario()
        {
            Console.WriteLine("Before scenario");
        }

        [Given(@"user in the login page")]
        public void GivenUserInTheLoginPage()
        {
            driverPageObject.BrowserSetUp();
            loginPageObject = new LoginPage();
        }

        [Given(@"user enter (.*) (.*)")]
        public void GivenUserEnterUsernamePassword(string username, string password)
        {
            loginPageObject.AddLoginCredentials(username, password);
        }


        [When(@"user click on login button")]
        public void WhenUserClickOnLoginButton()
        {
            loginPageObject.ClickLogin();
        }

        [Then(@"user navigate to home page")]
        public void ThenUserNavigateToHomePage()
        {
            var expectedUrl = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
            var actualUrl = loginPageObject.NavigatedToHomePage();
            Assert.AreEqual(expectedUrl, actualUrl);
        }

        [AfterScenario]
        public void Quit()
        {

            driverPageObject.CloseBrowser();
            driverPageObject.CloseBrowser();
        }


    }
}
